﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using GenesisInterfaces;

namespace Panel_Script
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //s_ix , s_iy, w_ix, w_iy, x_step_num, y_step_num, x_step_spec, y_step_spec are TextBox controls in the XAML file
            TextBox s_ix = this.FindName("six") as TextBox;
            s_ix.Text = "0.0";

            TextBox s_iy = this.FindName("siy") as TextBox;
            s_iy.Text = "0.0";

            TextBox w_ix = this.FindName("wix") as TextBox;
            w_ix.Text = "0.0";

            TextBox w_iy = this.FindName("wiy") as TextBox;
            w_iy.Text = "0.0";

            TextBox x_step_num = this.FindName("xstep_num") as TextBox;
            x_step_num.Text = "1";

            TextBox y_step_num = this.FindName("ystep_num") as TextBox;
            y_step_num.Text = "1";

            TextBox x_step_spec = this.FindName("xstep_spec") as TextBox;
            x_step_spec.Text = "2.0";

            TextBox y_step_spec = this.FindName("ystep_spec") as TextBox;
            y_step_spec.Text = "2.0";

                      stpSlect.ItemsSource = new List<string> { "載入中..." };
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
    {
        // 先檢查 JOB 變數
        Console.WriteLine($"PanelScript.JOB = '{PanelScript.JOB}'");

        if (string.IsNullOrEmpty(PanelScript.JOB))
        {
            stpSlect.ItemsSource = new List<string> { "錯誤: JOB 未設定" };
            return;
        }

        Console.WriteLine("準備執行 Gen.INFO...");

        // 執行 Genesis API
        Gen.INFO($" -t job -e {PanelScript.JOB} -m script -d STEPS_LIST");

        Console.WriteLine("Gen.INFO 執行完成");

        List<string> steps = new List<string>(Gen.GetInfo("gSTEPS_LIST"));
        stpSlect.ItemsSource = steps;

        Console.WriteLine($"載入了 {steps.Count} 個步驟");

    }
    catch (Exception ex)
    {
        Console.WriteLine($"錯誤: {ex.Message}");
        Console.WriteLine($"堆疊追蹤: {ex.StackTrace}");
        stpSlect.ItemsSource = new List<string> { $"錯誤: {ex.Message}" };
    }
            //try
            //{
            //    // 在這裡執行 Genesis API 呼叫
            //    Gen.INFO($" -t job -e {PanelScript.JOB} -m script -d STEPS_LIST");
            //    List<string> steps = new List<string>(Gen.GetInfo("gSTEPS_LIST"));

            //    stpSlect.ItemsSource = steps;
            //    Gen.PAUSE("test");
            //}
            //catch (Exception ex)
            //{
            //    // 錯誤處理
            //    stpSlect.ItemsSource = new List<string> { "載入失敗: " + ex.Message };
            //}
        }

        private void s_ix(object sender, TextChangedEventArgs e)
        {
        }

        private void s_iy(object sender, TextChangedEventArgs e)
        {
        }

        private void w_ix(object sender, TextChangedEventArgs e)
        {
        }

        private void w_iy(object sender, TextChangedEventArgs e)
        {
        }

        private void x_step_num(object sender, TextChangedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void y_step_num(object sender, TextChangedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void x_step_spec(object sender, TextChangedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void y_step_spec(object sender, TextChangedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Layer_List(object sender, SelectionChangedEventArgs e)
        {
        }


        private void onclick_run_btn(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}