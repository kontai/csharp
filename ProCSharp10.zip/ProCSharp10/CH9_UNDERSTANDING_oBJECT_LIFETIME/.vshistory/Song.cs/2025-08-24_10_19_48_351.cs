﻿namespace LazyObjectInstantiation;
// Represents a single song.
class Song
{
  public string Artist { get; set; }
  public string TrackName { get; set; }
  public double TrackLength { get; set; }
}