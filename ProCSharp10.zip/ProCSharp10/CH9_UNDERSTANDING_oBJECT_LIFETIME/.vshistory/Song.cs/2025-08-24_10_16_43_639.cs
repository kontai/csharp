﻿namespace SimpleGC;

public class Song
{
    
}