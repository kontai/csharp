﻿namespace CH9_UNDERSTANDING_oBJECT_LIFETIME;

public class LazyProgram
{
    
}