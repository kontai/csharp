﻿namespace GCProjNS;

public class MyResourceWrapper
{
    
}