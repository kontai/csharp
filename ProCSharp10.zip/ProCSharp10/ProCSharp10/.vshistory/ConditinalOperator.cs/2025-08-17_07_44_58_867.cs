﻿namespace CH3_Constructs_Part1;

public class ConditinalOperator
{
    
}