﻿namespace Employees;

partial class Employee
{
    public string Name { get; set; }
    public int Age { get; set; }
    public Employee() { } // 確保預設建構子存在

}
