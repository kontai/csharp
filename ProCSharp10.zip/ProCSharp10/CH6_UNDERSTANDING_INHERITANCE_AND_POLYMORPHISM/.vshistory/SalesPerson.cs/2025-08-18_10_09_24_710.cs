﻿namespace Employees;

public class SalesPerson
{
    
}