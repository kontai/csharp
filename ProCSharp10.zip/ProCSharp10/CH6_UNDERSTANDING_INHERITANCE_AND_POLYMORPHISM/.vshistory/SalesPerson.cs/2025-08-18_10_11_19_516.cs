﻿namespace Employees;

class SalesPerson : Employee
{
    public int SalesNumber { get; set; }
}
