﻿namespace CH6_UNDERSTANDING_INHERITANCE_AND_POLYMORPHISM;

public class Class1
{
    
}