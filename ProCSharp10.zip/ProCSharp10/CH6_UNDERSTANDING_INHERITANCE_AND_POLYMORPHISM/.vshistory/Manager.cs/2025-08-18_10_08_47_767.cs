﻿namespace Employees;

public class Manager
{
    
}