﻿namespace Employees;

class Manager : Employee
{
    public int StockOptions { get; set; }
}
