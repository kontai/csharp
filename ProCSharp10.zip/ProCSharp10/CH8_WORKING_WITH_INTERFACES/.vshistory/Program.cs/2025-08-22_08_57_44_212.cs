﻿using System.Collections;

Garage garage=new Garage();
//foreach (var o in garage)
//{
//    Console.WriteLine(o);
//}
//IEnumerator enumerator= garage.GetEnumerator();
foreach (var car in garage)
{
    Console.WriteLine(car);
}
