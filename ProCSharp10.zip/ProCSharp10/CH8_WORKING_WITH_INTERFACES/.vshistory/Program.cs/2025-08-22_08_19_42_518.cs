﻿Garage garage=new Garage();
foreach (var o in garage)
{
    Console.WriteLine(o);
}