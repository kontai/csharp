﻿using System.Collections;

Garage garage=new Garage();
//foreach (var o in garage)
//{
//    Console.WriteLine(o);
//}
IEnumerator enumerator= garage.GetEnumerator();
