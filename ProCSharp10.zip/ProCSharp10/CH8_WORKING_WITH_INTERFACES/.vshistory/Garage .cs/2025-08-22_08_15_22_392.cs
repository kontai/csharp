﻿namespace CH8_WORKING_WITH_INTERFACES;

public class Garage_
{
    
}