﻿namespace SimpleInterfaces;

public class Point
{
    
}