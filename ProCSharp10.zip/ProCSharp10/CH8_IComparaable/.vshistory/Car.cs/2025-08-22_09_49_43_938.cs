﻿namespace CH8_IComparaable;

public class Car
{
    
}