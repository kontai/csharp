﻿namespace CH8_IComparaable;

public class PetNameComparer_
{
    
}