﻿namespace CH4_Constructs_Part2;

public class FunWithStructures
{
    
}