﻿namespace SimpleException;

public class CarIsDeadException
{
    
}