﻿namespace CH7_ExceptIon_HandlIng;

public class Car
{
    
}