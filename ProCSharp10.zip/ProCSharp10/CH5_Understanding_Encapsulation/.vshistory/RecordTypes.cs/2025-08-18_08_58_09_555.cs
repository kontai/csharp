﻿namespace CH5_Understanding_Encapsulation;

public class RecordTypes
{
    
}