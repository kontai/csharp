﻿namespace CH5_Understanding_Encapsulation;

public partial class Program
{
        public static string SayHello() => "Hello";
}