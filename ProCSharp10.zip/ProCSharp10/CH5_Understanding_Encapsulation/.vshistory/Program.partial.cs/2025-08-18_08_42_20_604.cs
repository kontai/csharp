﻿namespace CH5_Understanding_Encapsulation;

public class Program_partial
{
    
}